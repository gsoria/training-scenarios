Congratulations - you finished the getting started with PatternFly donut chart course!

> Learn more about PatternFly React:
>- [Getting started with PatternFly](https://www.patternfly.org/v4/get-started/developers)
>- [PatternFly React documentation](https://www.patternfly.org/v4/documentation/react/components/)
>- [PatternFly donut chart documentation](https://patternfly-react.surge.sh/patternfly-4/charts/chartdonut/)
>- [Victory chart documentation](https://formidable.com/open-source/victory/docs/victory-chart/)
