In this scenario, you will learn how to use PatternFly React donut chart components for the first time.
