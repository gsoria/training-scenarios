In this scenario, you will learn how to use PatternFly React stack chart components for the first time.
