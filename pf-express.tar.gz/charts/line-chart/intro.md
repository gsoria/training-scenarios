In this scenario, you will learn how to use PatternFly React line chart components for the first time.
