Congratulations - you finished the getting started with PatternFly line chart course!

> Learn more about PatternFly React:
>- [Getting started with PatternFly](https://www.patternfly.org/v4/get-started/developers)
>- [PatternFly React documentation](https://www.patternfly.org/v4/documentation/react/components/)
>- [PatternFly line chart documentation](https://patternfly-react.surge.sh/patternfly-4/charts/chartline/)
>- [Victory chart documentation](https://formidable.com/open-source/victory/docs/victory-chart/)
