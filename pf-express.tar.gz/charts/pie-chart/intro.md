In this scenario, you will learn how to use PatternFly React pie chart components for the first time.
