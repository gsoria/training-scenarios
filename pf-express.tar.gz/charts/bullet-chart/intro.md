In this scenario, you will learn how to use PatternFly React bullet chart components for the first time.
