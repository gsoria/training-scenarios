PatternFly React is made up of components, layouts and demos.

The PatternFly React library provides a collection of React demos you can use to build more complex interfaces with consistent markup, styling, and behavior. In this course, we're going to build a PatternFly page together - starting with a demo, adding cards, and concluding with modifying the cards and their content. You'll learn a little bit about how to use PatternFly components together to build a consistent experience.
