In this scenario, you will learn how to use a PatternFly 4 React demo for the first time and customize components.
