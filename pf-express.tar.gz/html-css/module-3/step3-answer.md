```
<div class="pf-c-alert pf-m-success">
  <div class="pf-c-alert__icon">
    <i class="fas fa-info-circle"></i>
  </div>
  <h4 class="pf-c-alert__title">
    Alert one
  </h4>
</div>

<div class="pf-c-alert pf-m-warning pf-m-inline">
  <div class="pf-c-alert__icon">
    <i class="fas fa-info-circle"></i>
  </div>
  <h4 class="pf-c-alert__title">
    Alert two
  </h4>
</div>

<div class="pf-c-alert pf-m-info pf-m-danger">
  <div class="pf-c-alert__icon">
    <i class="fas fa-info-circle"></i>
  </div>
  <h4 class="pf-c-alert__title">
    Alert three
  </h4>
</div>
```
