```
<div class="pf-c-dropdown pf-m-expanded">
  <button class="pf-c-dropdown__toggle">
    <span class="pf-c-dropdown__toggle-text">
            Collapsed dropdown
      </span>
    <i class="fas fa-caret-down pf-c-dropdown__toggle-icon"></i>
  </button>
  <ul class="pf-c-dropdown__menu">
    <li>
      <a class="pf-c-dropdown__menu-item" href="#">Link</a>
    </li>
    <li>
      <a class="pf-c-dropdown__menu-item" href="#">Link</a>
    </li>
    <li>
      <button class="pf-c-dropdown__menu-item" disabled>Disabled action</button>
    </li>
    </li>
  </ul>
</div>
```
