Congratulations on successfully finishing this module. 
As a reminder, you will find the documentation for all modifier classes at the end of each component page. 
PatternFly also has a link to the total list of modifiers that we have: 
https://pf4.patternfly.org/modifiers 