Module 3: Modifier and Utility Classes

This module will deep dive into how to utilize and create modifier classes per component and how to efficiently use utility classes across the UI.