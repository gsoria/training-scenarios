```
<span class="pf-c-badge pf-m-unread">
  200
</span>
<span class="pf-c-badge pf-m-read">
  300
</span>
```
