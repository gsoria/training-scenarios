```
<header class="pf-l-split">
  <div class="pf-l-split__item">
    Align left.
  </div>
  <div class="pf-l-split__item pf-m-fill">
    This element should fill the remaining space between the left and right elements.
  </div>
  <div class="pf-l-split__item">
    Align right.
  </div>
</header>
```
