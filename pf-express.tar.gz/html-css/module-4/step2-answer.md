```
<div class="pf-c-card">
  <div class="pf-c-card__body pf-l-level">
    <h1 class="pf-c-title pf-m-xl">
      Large title
    </h1>
    <button class="pf-c-button pf-m-primary">
      Click me
    </button>
  </div>
</div>
```
