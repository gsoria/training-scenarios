```
<div class="pf-c-card" style="width: 450px"> 
  <div class="pf-c-card__body pf-l-flex pf-m-row pf-m-justify-content-space-between">
    <span>
      <h2>PatternFly-Elements</h2>
      <p>Working repo for PatternFly 4</p>
    </span>
    <button class="pf-c-button pf-m-primary">
      Primary
    </button>
  </div>
  <div class="pf-c-card__body pf-l-flex pf-m-row pf-m-justify-content-space-between">
    <span>
      <h2>PatternFly-Elements</h2>
      <p>Working repo for PatternFly 4</p>
    </span>
    <button class="pf-c-button pf-m-primary">
      Primary
    </button>
  </div>
  <div class="pf-c-card__footer pf-l-flex pf-m-justify-content-space-between">
    <button class="pf-c-button pf-m-secondary">
      Secondary
    </button>
    <button class="pf-c-button pf-m-secondary">
      Secondary
    </button>
    <button class="pf-c-button pf-m-secondary">
      Secondary
    </button>
  </div>
</div>
```
