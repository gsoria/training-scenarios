```
<div class="pf-c-card" style="height: 450px; width: 300px;">
  <div class="pf-c-card__body pf-l-stack">
    <h1 class="pf-c-title pf-m-2xl pf-l-stack__item">
      This is a title
    </h1>
    <div class="pf-l-stack__item pf-m-fill">
      Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
    </div>
    <button class="pf-c-button pf-m-link pf-m-inline pf-l-stack__item">
      Footer Link Button
    </button>
  </div>
</div>
```
