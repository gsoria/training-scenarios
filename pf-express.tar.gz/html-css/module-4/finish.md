Congratulations on finishing this module. Now you should be able to use all of Patternfly’s layouts in your products.

Here are some more resources:
Bullseye Layout: https://www.patternfly.org/v4/documentation/core/layouts/bullseye
Flex Layout:
https://www.patternfly.org/v4/documentation/core/layouts/flex
Gallery Layout:
https://www.patternfly.org/v4/documentation/core/layouts/gallery
Grid Layout
https://www.patternfly.org/v4/documentation/core/layouts/grid
Level Layout
https://www.patternfly.org/v4/documentation/core/layouts/level
Split Layout
https://www.patternfly.org/v4/documentation/core/layouts/split
Stack Layout
https://www.patternfly.org/v4/documentation/core/layouts/stack
