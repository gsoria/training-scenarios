```
<span class="pf-c-label">
  <i class="pf-c-label__icon fas fa-plus"></i>
  My custom label
</span>

.pf-c-label {
  --pf-c-label__icon--MarginRight: var(--pf-global--spacer--sm);
}

.pf-c-label__icon {
  margin-right: var(--pf-c-label__icon--MarginRight);
}
```
