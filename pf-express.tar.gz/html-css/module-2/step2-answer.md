```
This is a <a href="#">test link</a>.

:root {
  --pf-global--link--Color: var(--pf-global--danger-color--100);
}
```
