```
<nav class="pf-c-nav">
  <ul class="pf-c-nav__simple-list">
    <li class="pf-c-nav__item">
      <a href="#" class="pf-c-nav__link pf-m-current">
        Current link
      </a>
    </li>
    <li class="pf-c-nav__item">
      <a href="#" class="pf-c-nav__link">
        Link 2
      </a>
    </li>
    <li class="pf-c-nav__item">
      <a href="#" class="pf-c-nav__link">
        Link 3
      </a>
    </li>
  </ul>
</nav>
```
