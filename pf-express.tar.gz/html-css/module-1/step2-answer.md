```
<div class="pf-c-chip">
  <span class="pf-c-chip__text">
    Chip
  </span>
    <span class="pf-c-badge pf-m-read">
        7
  </span>
  <button class="pf-c-button pf-m-plain">
  <i class="fas fa-times-circle"></i>
  </button>
</div>
```
