```
<button class="pf-c-button pf-m-primary" type="button">
  Primary
</button>
<button class="pf-c-button pf-m-primary" type="button">
  Primary
</button>
```
