```
<div class="pf-l-bullseye">
  <div class="pf-c-card">
    <div class="pf-c-card__header pf-c-title pf-m-md">
      Header
    </div>
    <div class="pf-c-card__body">
      Body
    </div>
    <div class="pf-c-card__footer">
      Footer
    </div>
  </div>
</div>
```
